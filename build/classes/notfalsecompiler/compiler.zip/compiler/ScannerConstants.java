package notfalsecompiler.compiler;

import notfalsecompiler.util.importador.Importador;

public interface ScannerConstants
{
    int[][] SCANNER_TABLE = new Importador().getTabela();

    int[] TOKEN_STATE = { 0,  0, 43, -1, 34, 46, -1, 60, 61, 32, 23, 55, 24, 54, 31, 10, 10, 57, 56, 36, 33, 35,  2, 58, 59, 48, 62, 47, 63, 49, 40, -1, 30, 41, -1, 29, 26, 27, -1, 52, 28, -1, -1, 14, 45, 38, 39, 37, 44, 42, -1, 12, -1, -1, -1, 11, 15, 13, -1, 53, -1, -1, 53 };

    int[] SPECIAL_CASES_INDEXES =
        { 0, 0, 0, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17 };

    String[] SPECIAL_CASES_KEYS =
        {  "bool", "char", "do", "elif", "else", "end", "float", "for", "function", "if", "int", "return", "string", "sysin", "sysout", "void", "while" };

    int[] SPECIAL_CASES_VALUES =
        {  6, 8, 22, 17, 18, 19, 4, 20, 7, 16, 3, 64, 5, 50, 51, 9, 21 };

    String[] SCANNER_ERROR =
    {
        "Caractere n�o esperado",
        "",
        "",
        "Erro identificando STRING",
        "",
        "",
        "Erro identificando CARACTER",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "Erro identificando STRING",
        "",
        "",
        "Erro identificando CARACTER",
        "",
        "",
        "",
        "Erro identificando MULTI_COMMENT",
        "",
        "",
        "Erro identificando REAL",
        "Erro identificando BINARY",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "Erro identificando STRING",
        "",
        "Erro identificando MULTI_COMMENT",
        "Erro identificando MULTI_COMMENT",
        "Erro identificando MULTI_COMMENT",
        "",
        "",
        "",
        "Erro identificando MULTI_COMMENT",
        "",
        "Erro identificando MULTI_COMMENT",
        "Erro identificando MULTI_COMMENT",
        ""
    };

}
